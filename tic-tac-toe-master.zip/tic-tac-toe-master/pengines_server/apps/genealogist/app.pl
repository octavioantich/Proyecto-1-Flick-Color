:- module(app_genealogist, []).
:- use_module(library(pengines)).

:- pengine_application(genealogist).
:- use_module(genealogist:genealogist).

